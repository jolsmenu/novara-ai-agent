# ─── User context builder ──────────────────────────────────────────────────────
def build_user_context(client_time: str = "", client_location: str = "") -> str:
    memory = load_user_memory()
    lines  = ["=== MANDATORY USER CONTEXT — HIGHEST PRIORITY ==="]
    if memory:
        lines.append("REMEMBERED USER INFO: " +
   	   	           ", ".join(f"{k}={v}" for k, v in memory.items()))
    lines += [
        "ABSOLUTE RULES:",
        "  • Use the user's time/location only when relevant to the query (timezones, scheduling, local times, etc.).",
        "  • Never say 'I don't know' or use placeholders unless truly necessary.",
        "  • Never say 'depending on your timezone' or 'currently it's [time]' unless specifically asked.",
        "  • Use remembered info naturally — never ask the user for info you already have.",
        "=================================================",
    ]
    return "\n".join(lines)