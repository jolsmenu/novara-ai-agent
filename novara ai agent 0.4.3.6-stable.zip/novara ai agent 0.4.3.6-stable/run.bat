# Updating the batch file to include a robust "kill previous" feature.
# We will target both 'python.exe' and 'pythonw.exe' to ensure no leftover instances exist.

batch_content = """@echo off
setlocal

echo [INFO] --- Starting Environment Check ---

:: Kill existing python processes to ensure a clean slate
echo [INFO] Cleaning up previous instances...
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /IM pythonw.exe >nul 2>&1

:: 1. Check if Python is installed
python --version >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in your PATH.
    pause
    exit /b
)
echo [STATUS] Python: OK

:: 2. Check for pip
pip --version >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] 'pip' is not found.
    pause
    exit /b
)
echo [STATUS] Pip: OK

:: 3. Check for Ollama
where ollama >nul 2>nul
if %errorlevel% neq 0 (
    echo [STATUS] Ollama: NOT INSTALLED. Installing...
    winget install Ollama.Ollama
) else (
    for /f "tokens=*" %%i in ('ollama --version') do set OLLAMA_VER=%%i
    echo [STATUS] Ollama: INSTALLED (%OLLAMA_VER%)
)

:: 4. Check/Install Python libraries
echo [STATUS] Checking Python dependencies...
python -c "import requests; import flask; from flask_cors import CORS" >nul 2>nul
if %errorlevel% neq 0 (
    echo [INFO] Installing required Python libraries...
    pip install requests flask flask-cors
) else (
    echo [STATUS] Python libraries: OK
)

:: 5. Launch App
echo [INFO] --- Environment Ready ---
echo [INFO] Starting Application...

start "" "index.html"
python app.py

endlocal
"""

with open("run.bat", "w") as f:
    f.write(batch_content)