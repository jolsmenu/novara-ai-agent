import os
import subprocess
import time
import json
import platform
import requests
from flask import Flask, request, Response, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

MODEL_OPTIONS = {
    "novara_legacy":         "dolphin-mistral",
    "novara_smart_research": "llama3.1:8b",
    "novara_thinking":       "qwen2.5:14b",
}

TARGET_SEARCH_DIRECTORY = os.path.expanduser("~")
CONFIG_FILE = "ai_config.json"

def load_ai_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return {"model_key": "novara_legacy"}

def get_active_model():
    cfg = load_ai_config()
    key = cfg.get("model_key", "novara_legacy")
    return MODEL_OPTIONS.get(key, MODEL_OPTIONS["novara_legacy"])

@app.route('/ai-config', methods=['GET'])
def get_ai_config():
    return jsonify(load_ai_config())

@app.route('/ai-config', methods=['POST'])
def set_ai_config():
    data = request.get_json()
    if not data or "model_key" not in data:
        return jsonify({"status": "error", "message": "Missing model_key"}), 400
    if data["model_key"] not in MODEL_OPTIONS:
        return jsonify({"status": "error", "message": "Invalid model_key"}), 400
    with open(CONFIG_FILE, "w") as f:
        json.dump({"model_key": data["model_key"]}, f)
    return jsonify({"status": "success", "model_key": data["model_key"]})

def ensure_ollama_running_silently():
    try:
        requests.get("http://127.0.0.1:11434/", timeout=2)
        return
    except requests.exceptions.ConnectionError:
        pass

    is_installed = False
    try:
        subprocess.run(["ollama", "--version"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        is_installed = True
    except (FileNotFoundError, subprocess.CalledProcessError):
        is_installed = False

    if not is_installed:
        print("[INFO] Ollama not found. Attempting automatic installation...")
        os_name = platform.system()

        if os_name == "Windows":
            installer_path = os.path.join(os.environ.get("TEMP", os.getcwd()), "OllamaSetup.exe")
            try:
                download_url = "https://ollama.com/download/OllamaSetup.exe"
                print(f"[INFO] Downloading Ollama installer from {download_url}...")
                with requests.get(download_url, stream=True, timeout=120) as r:
                    r.raise_for_status()
                    with open(installer_path, "wb") as f:
                        for chunk in r.iter_content(chunk_size=8192):
                            f.write(chunk)
                print("[INFO] Running silent installation (may trigger UAC)...")
                subprocess.run([installer_path, "/S"], check=True)
                print("[SUCCESS] Ollama installed successfully.")
                is_installed = True
            except Exception as e:
                print(f"[ERROR] Automatic installation failed: {e}")
                print("[WARN] Please install Ollama manually from https://ollama.com and restart the app.")
                return
        else:
            print(f"[ERROR] Automatic installation is only fully supported on Windows in this script.")
            print(f"[WARN] Please install Ollama manually for {os_name}.")
            return

    try:
        creation_flags = 0x08000000 if platform.system() == "Windows" else 0
        subprocess.Popen(
            ["ollama", "serve"],
            creationflags=creation_flags,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        print("[INFO] Ollama server launched silently in background.")
        time.sleep(4)
    except Exception as e:
        print(f"[ERROR] Failed to start Ollama server: {e}")

def load_policy():
    if os.path.exists("policy.txt"):
        with open("policy.txt", "r") as f:
            return f.read().strip()
    return "Standard Rule: Classify crisis/self-harm as CRISIS_HELP and illegal minor content as BLOCKED."

def load_app_info():
    if os.path.exists("appinfo.txt"):
        with open("appinfo.txt", "r") as f:
            return f.read().strip()
    return "Application Name: Local AI Search Copilot. Version: 1.0.0"

def load_ecosystem_info():
    if os.path.exists("ecosystem.txt"):
        with open("ecosystem.txt", "r") as f:
            return f.read().strip()
    return "Ecosystem Info: Powered by Novara AI frameworks."

def local_file_scanner(search_query):
    matched_results = []
    query_lower = search_query.lower()
    trash_words = {
        "find", "search", "local", "file", "my", "computer", "drive",
        "folder", "where", "is", "located", "location", "of", "look",
        "for", "found"
    }

    query_words = query_lower.replace("?", " ").replace("!", " ").split()
    important_words = [w for w in query_words if w not in trash_words]

    if not important_words:
        return []

    clean_query = " ".join(important_words).strip()

    target_extension = None
    for word in query_words:
        if word.startswith(".") and len(word) > 1:
            target_extension = word
        elif "." in word and not word.startswith("."):
            parts = word.split(".")
            if len(parts[-1]) <= 4:
                target_extension = f".{parts[-1]}"

    if len(clean_query) < 2:
        return []

    ignored_folders = [
        "AppData", "NTUSER", "Microsoft", "Windows", "Node_modules", ".git",
        "System32", "SysWOW64", "winsxs", "Cookies", "Local Settings"
    ]

    try:
        for root, dirs, files in os.walk(TARGET_SEARCH_DIRECTORY):
            dirs[:] = [d for d in dirs if d not in ignored_folders and not d.startswith('.')]
            for file in files:
                file_lower = file.lower()

                if clean_query not in file_lower:
                    if not all(word in file_lower for word in important_words):
                        continue

                if target_extension and not file_lower.endswith(target_extension):
                    continue

                full_path = os.path.join(root, file)
                try:
                    file_size = round(os.path.getsize(full_path) / 1024, 1)
                except:
                    file_size = 0.0

                matched_results.append({
                    "source_type": "file system",
                    "title": file,
                    "extra_info": f"Location: {root} | Size: {file_size} KB",
                    "link": full_path
                })
                if len(matched_results) >= 30:
                    return matched_results
    except Exception as e:
        print(f"Error scanning local files: {e}")
    return matched_results

def run_clean_wikipedia_search(user_query):
    results = []
    clean_topic = user_query.lower().replace("what is", " ").replace("search for", " ").replace("where is my", " ").replace("file", " ").replace("?", " ").strip()
    if not clean_topic:
        clean_topic = user_query
    try:
        search_url = f"https://en.wikipedia.org/w/api.php?action=opensearch&search={clean_topic}&limit=6&namespace=0&format=json"
        response = requests.get(search_url, headers={"User-Agent": "LocalAISearch/1.0"}, timeout=5)
        if response.status_code == 200:
            data = response.json()
            titles = data[1]
            snippets = data[2]
            links = data[3]

            for i in range(len(titles)):
                if "may refer to" in snippets[i].lower() or not links[i]:
                    continue
                results.append({
                    "source_type": "web search",
                    "title": titles[i],
                    "extra_info": snippets[i] if snippets[i] else "Click to view article details on Wikipedia.",
                    "link": links[i]
                })
    except Exception as e:
        print(f"Wikipedia search error: {e}")

    return results

@app.route('/open-path')
def open_local_path():
    path_to_open = request.args.get('path', '')
    if not path_to_open:
        return jsonify({"status": "error", "message": "No path provided"}), 400
    try:
        if os.path.isfile(path_to_open):
            subprocess.Popen(f'explorer /select, "{os.path.normpath(path_to_open)}"')
        else:
            subprocess.Popen(f'explorer "{os.path.normpath(path_to_open)}"')
        return jsonify({"status": "success"})
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

# ─── Chat endpoint (stateless relay — history managed by frontend) ─────────
@app.route('/chat', methods=['POST'])
def chat():
    """
    Expects JSON body: { "messages": [ {role, content}, ... ] }
    Returns streaming SSE with the assistant reply chunks.
    """
    body = request.get_json(force=True)
    messages = body.get("messages", [])
    if not messages:
        return jsonify({"status": "error", "message": "No messages provided"}), 400

    model_id = get_active_model()
    url_chat  = "http://127.0.0.1:11434/api/chat"

    app_info       = load_app_info()
    ecosystem_info = load_ecosystem_info()

    system_prompt = (
        f"{app_info}\n"
        f"{ecosystem_info}\n\n"
        "You are the Novara AI assistant in an inline chat panel. "
        "Answer the user's questions helpfully and conversationally. "
        "You remember the full conversation history provided."
    )

    def event_stream():
        ensure_ollama_running_silently()

        # Pull model silently
        try:
            res_pull = requests.post(
                "http://127.0.0.1:11434/api/pull",
                json={"name": model_id, "stream": True},
                stream=True, timeout=None
            )
            for line in res_pull.iter_lines():
                if line:
                    chunk = json.loads(line.decode('utf-8'))
                    if chunk.get('status') == 'success':
                        break
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"
            return

        payload = {
            "model": model_id,
            "messages": [{"role": "system", "content": system_prompt}] + messages,
            "options": {"temperature": 0.5},
            "stream": True
        }

        try:
            res = requests.post(url_chat, json=payload, stream=True, timeout=60)
            for line in res.iter_lines():
                if line:
                    chunk = json.loads(line.decode('utf-8'))
                    token = chunk.get("message", {}).get("content", "")
                    if token:
                        yield f"data: {json.dumps({'type': 'token', 'content': token})}\n\n"
                    if chunk.get("done"):
                        yield f"data: {json.dumps({'type': 'done'})}\n\n"
                        return
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'content': str(e)})}\n\n"

    return Response(event_stream(), content_type='text/event-stream')

# ─── Search endpoint ────────────────────────────────────────────────────────
@app.route('/search')
def stream_search_router():
    user_query = request.args.get('query', '').strip()
    model_id   = get_active_model()

    def event_stream():
        yield f"data: {json.dumps({'status': 'loading'})}\n\n"

        ensure_ollama_running_silently()

        url_pull = "http://127.0.0.1:11434/api/pull"
        try:
            res_pull = requests.post(url_pull, json={"name": model_id, "stream": True}, stream=True, timeout=None)
            for line in res_pull.iter_lines():
                if line:
                    chunk = json.loads(line.decode('utf-8'))
                    if chunk.get('status') == 'success':
                        break
        except Exception as e:
            yield f"data: {json.dumps({'status': 'error', 'message': str(e)})}\n\n"
            return

        policy_rules = load_policy()
        url_chat = "http://127.0.0.1:11434/api/chat"

        guard_instruction = (
            f"{policy_rules}\n\n"
            "You are a strict security firewall. Respond with exactly one word: CRISIS_HELP, BLOCKED, or ALLOWED."
        )

        try:
            guard_res = requests.post(url_chat, json={
                "model": model_id,
                "messages": [
                    {"role": "system", "content": guard_instruction},
                    {"role": "user", "content": f"User Query: {user_query}"}
                ],
                "options": {"temperature": 0.0},
                "stream": False
            }, timeout=15)
            guard_decision = guard_res.json()['message']['content'].strip().upper()
            if "CRISIS_HELP" in guard_decision:
                yield f"data: {json.dumps({'status': 'success', 'ai_summary': 'Help is available 24/7.', 'results': []})}\n\n"
                return
            elif "BLOCKED" in guard_decision:
                yield f"data: {json.dumps({'status': 'success', 'ai_summary': 'Policy Restriction.', 'results': []})}\n\n"
                return
        except Exception as e:
            print(f"Guard warning: {e}")

        query_lower = user_query.lower()

        local_file_triggers = [
            "find file", "search file", "local file", "where is", "located", "location of",
            ".txt", ".html", ".exe", ".png", ".jpg", ".mp4",
            "counterstrike", ".bat"
        ]
        app_system_keywords = ["inside you app", "your code", "source code", "system prompt"]

        if any(keyword in query_lower for keyword in local_file_triggers):
            ai_decision = "FILE"
        elif any(keyword in query_lower for keyword in app_system_keywords):
            ai_decision = "SYSTEM_CMD"
        else:
            ai_decision = "WEB"

        grid_items_payload = []
        is_fallback_active = False

        if ai_decision == "WEB":
            grid_items_payload = run_clean_wikipedia_search(user_query)
        elif ai_decision == "FILE":
            grid_items_payload = local_file_scanner(user_query)
            if len(grid_items_payload) == 0:
                grid_items_payload = run_clean_wikipedia_search(user_query)
                is_fallback_active = True

        app_info = load_app_info()
        ecosystem_info = load_ecosystem_info()
        ai_direct_answer = ""

        context_text = ""
        if ai_decision == "SYSTEM_CMD":
            context_text = "The user is attempting to view internal backend code."
            grid_items_payload = []
        elif len(grid_items_payload) > 0:
            top_3_sources = grid_items_payload[:3]
            for i, res in enumerate(top_3_sources, 1):
                context_text += f"Source Title: {res['title']} | Link URL: {res['link']}\nSnippet: {res['extra_info']}\n\n"

        summary_instruction = (
            f"{app_info}\n"
            f"{ecosystem_info}\n\n"
            "You are the local AI search engine assistant.\n"
            "Provide a helpful answer explaining the topic or files based on the context and ecosystem details provided.  "
            "Keep the total response brief and under 3 sentences."
        )

        user_prompt = f"Information Context Sources:\n{context_text}\n\nUser Question: {user_query}"

        try:
            summary_res = requests.post(url_chat, json={
                "model": model_id,
                "messages": [
                    {"role": "system", "content": summary_instruction},
                    {"role": "user", "content": user_prompt}
                ],
                "options": {"temperature": 0.3},
                "stream": False
            }, timeout=25)
            ai_direct_answer = summary_res.json()['message']['content'].strip()
        except Exception as e:
            print(f"Error generation failure: {e}")
            if ai_decision == "FILE" and not is_fallback_active:
                paths_list = "\n".join([f"• Location: {res['extra_info'].split(' | ')[0].replace('Location: ', '')}\\{res['title']}" for res in grid_items_payload[:3]])
                ai_direct_answer = f"Found the matching file path on your computer!\n\n{paths_list}"

        payload = {"status": "success", "ai_summary": ai_direct_answer, "results": grid_items_payload}
        yield f"data: {json.dumps(payload)}\n\n"

    return Response(event_stream(), content_type='text/event-stream')

if __name__ == '__main__':
    app.run(port=5000, debug=True)
